/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;
import models.*;
import views.*;
import controllers.*;
import models.ModelMain;

/**
 *
 * @author Lupita-mi-amor
 */
public class Main {
    
    public static void main (String jagb[]){
        ModelMain model_main = new ModelMain();
        ModelUsuario model_usuario = new ModelUsuario(model_main);
        
        ViewMain view_main = new ViewMain();
        ViewUsuario view_usuario = new ViewUsuario();
        ViewAdmin view_admin = new ViewAdmin();
        ViewVendedor view_vendedor = new ViewVendedor();
        
        Object[] models = new Object[2];
        Object[] views = new Object[4];
        Object[] controllers = new Object[2];
        
        models[0] = model_main;
        models[1] = model_usuario;
        
        views[0] = view_main;
        views[1] = view_usuario;
        views[2] = view_admin;
        views[3] = view_vendedor;
        
        
        ControllerMain controller_main = new ControllerMain(models, views);
        controllers[0] = controller_main;
        
        ControllerUsuario controller_usuario = new ControllerUsuario(models, views, controllers);
        controllers[1] = controller_usuario;
        
       
    }
    
}
