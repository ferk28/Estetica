
package controllers;
import models.ModelUsuario;
import views.ViewMain;
import views.ViewUsuario;
/**
 *
 * @author Lupita-mi-amor
 */
public final class ControllerUsuario {
    
    private final ModelUsuario model_usuario;
    private final ViewMain view_main;
    private final ViewUsuario view_usuario;
    private final ControllerMain controller_main; 
    
    public ControllerUsuario(Object[] models, Object[] views, Object[] controllers){
        this.model_usuario = (ModelUsuario)models[1];
        this.view_main = (ViewMain)views[0];
        this.view_usuario = (ViewUsuario)views[1];
        this.controller_main = (ControllerMain)controllers[0];
        initView();
    }
    
    public void initView(){
        Definir_Action_Listeners();
    }
    
    public void Definir_Action_Listeners(){
        view_usuario.jbtn_iniciar.addActionListener(e-> jbtn_iniciarMouseClicked());
    }
    
    public void setDatos(){
        model_usuario.setUsuario(view_usuario.jtf_usuario.getText());
        model_usuario.setContraseña_Usuario(view_usuario.jpwd_contraseña.getPassword());
    }
    
    public void jbtn_iniciarMouseClicked(){
        setDatos();
        model_usuario.Verificar_Usuario();
        model_usuario.Verificar_Tipo_Usuario();
        if(model_usuario.getTipo_Usuario().equals("Admin")){
            view_main.jmi_admin.setVisible(true);
            view_main.jmi_vendedor.setVisible(false);
        }
        else{
            view_main.jmi_vendedor.setVisible(true);
            view_main.jmi_admin.setVisible(false);
        }
        view_usuario.jtf_usuario.setText("");
        view_usuario.jpwd_contraseña.setText("");
    }
}